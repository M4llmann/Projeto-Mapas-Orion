import React from 'react';
import { View, Text } from 'react-native';

export default function InfoScreen() {
  return (
    <View className="flex-1 items-center justify-center">
      <Text className="text-xl font-bold">Information Screen</Text>
    </View>
  );
}